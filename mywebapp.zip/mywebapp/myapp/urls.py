# myapp/urls.py
from django.contrib import admin
from django.urls import path
from . import views  # Import all views from views.py

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', views.login_view, name='login'),
    path('', views.home_view, name='home'),  # Use home_view for the root path
    path('dashboard/', views.dashboard_view, name='dashboard'),  # Use views.dashboard_view
    path('submit_request/', views.submit_request_view, name='submit_request'),  # Use views.submit_request_view
]
