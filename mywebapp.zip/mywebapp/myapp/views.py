# myapp/views.py

from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage  # Import FileSystemStorage
from pathlib import Path
from dotenv import load_dotenv
from openai import OpenAI
import os

load_dotenv()


def login_view(request):
    if request.method == 'POST':
        # Get the username and password from the POST data
        testid = os.getenv('TESTID') 
        testpw = os.getenv('TESTPW') 
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        # Check if the credentials are correct
        if username == testid and password == testpw:
            return redirect('dashboard')
        else:
            # Display an error message for invalid credentials
            return HttpResponse("Invalid credentials, please try again.")
    
    # Render the login form for GET requests
    return render(request, 'login.html')

def home_view(request):
    return render(request, 'home.html')  # Adjust template as needed

def dashboard_view(request):
    if request.method == 'POST':
        # Get the text input
        chat_input = request.POST.get('chat_input')

        # Handle file upload (if any)
        file = request.FILES.get('file_upload')
        if file:
            fs = FileSystemStorage()
            filename = fs.save(file.name, file)
            file_url = fs.url(filename)
        else:
            file_url = None

        # Simulate sending the request to the ChatGPT assistant
        assistant_response = process_chat_request(chat_input, file)

        # Render the dashboard with the assistant's response
        return render(request, 'dashboard.html', {
            'assistant_response': assistant_response,
            'file_url': file_url
        })
    
    # For GET requests, just display the dashboard without any response
    return render(request, 'dashboard.html')

# Simulated function to send a request to ChatGPT assistant
def process_chat_request(input_text, file=None):
    # Placeholder logic to simulate sending input to ChatGPT
    response = f"ChatGPT Assistant Response to: {input_text}"
    if file:
        response += f" and received file: {file.name}"
    return response

# View for handling form submission and file upload
def submit_request_view(request):
    if request.method == "POST":
        # Load the OpenAI API key
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return render(request, 'error.html', {'message': 'API key not found'})

        # Initialize the OpenAI client
        openai = OpenAI(api_key=api_key)

assistant = openai.beta.assistants.create(
  name="test",
  instructions="You are a personal math tutor. Write and run code to answer math questions.",
  tools=[{"type": "code_interpreter"}],
  model="gpt-4o",
)
        # # Extract the form data
        # user_input = request.POST.get('user_input')

        # # Create a message and execute a run in the OpenAI thread
        # try:
        #     # Example for generating a message
        #     message = client.beta.threads.messages.create(
        #         thread_id="thread_8RkbfLXODbn24bFzXuvkPjqD",
        #         role="user",
        #         content=user_input
        #     )

        #     run = client.beta.threads.runs.create(
        #         thread_id="thread_8RkbfLXODbn24bFzXuvkPjqD",
        #         assistant_id="asst_MqIv1uBTPQHoRCWLJgcVJQuP",
        #         instructions="Address the user as Dr. Alf."
        #     )

        #     return render(request, 'dashboard.html', {'response': run})

        # except Exception as e:
        #     return render(request, 'error.html', {'message': str(e)})
    return render(request, 'home.html')


def generate_cover_letter(request):
    if request.method == "POST":
        # Load the OpenAI API key
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return render(request, 'error.html', {'message': 'API key not found'})

        # Initialize the OpenAI client
        client = OpenAI(api_key=api_key)

        # Extract the form data
        user_input = request.POST.get('user_input')

        # Create a message and execute a run in the OpenAI thread
        try:
            # Example for generating a message
            message = client.beta.threads.messages.create(
                thread_id="thread_8RkbfLXODbn24bFzXuvkPjqD",
                role="user",
                content=user_input
            )

            run = client.beta.threads.runs.create(
                thread_id="thread_8RkbfLXODbn24bFzXuvkPjqD",
                assistant_id="asst_MqIv1uBTPQHoRCWLJgcVJQuP",
                instructions="Address the user as Dr. Alf."
            )

            return render(request, 'dashboard.html', {'response': run})

        except Exception as e:
            return render(request, 'error.html', {'message': str(e)})
    return render(request, 'home.html')